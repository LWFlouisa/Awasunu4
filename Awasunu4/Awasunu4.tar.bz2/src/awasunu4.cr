###########################################################################################
#                         Data Recycling And Memory Management                            #
###########################################################################################
# Focus on preserving knowledge through burial urns inside of obelisks. This started out  #
# as an esolang, and gradually became more useful for real world problems, such as the    #
# issue of catestrophic forgetting in AI models.                                          #
###########################################################################################
module Obelisk
  class DataRecycling
    macro obelisk_method(obelisk_method_name, obelisk_output, obelisk_content)
      def {{obelisk_method_name}}
        {{obelisk_content}}

        {{obelisk_output}}
      end
    end

    def self.obelisk(old_data)
      old_graveyard = File.read_lines("memoricimetiere/urn.txt").shuffle
      size_limit    = old_graveyard.size.to_i
      index = 0

      File.open("memoricimetiere/urn.txt", "w") { |f|
        f.puts old_data
      
        size_limit.times do
          f.puts old_graveyard[index]
          
          index = index + 1
        end
      }
    end

    def self.three_plot_burial(father, mother, child)
      buried_fathers  = File.read_lines("memoricimetiere/family/father.txt").uniq.sort
      buried_mothers  = File.read_lines("memoricimetiere/family/mother.txt").uniq.sort
      buried_children = File.read_lines("memoricimetiere/family/child.txt").uniq.sort

      File.open("memoricimetiere/family/father.txt", "w") { |f|
        f.puts father
        f.puts buried_fathers
      }
  
      File.open("memoricimetiere/family/mother.txt", "w") { |f|
        f.puts mother
        f.puts buried_mothers
      }
  
      File.open("memoricimetiere/family/child.txt", "w") { |f|
        f.puts child
        f.puts buried_children
      }
    end

    def self.four_plot_burial(father, mother, brother, sister)
      buried_fathers  = File.read_lines("memoricimetiere/family/father.txt").uniq.sort
      buried_mothers  = File.read_lines("memoricimetiere/family/mother.txt").uniq.sort
      buried_brothers = File.read_lines("memoricimetiere/family/brother.txt").uniq.sort
      buried_sisters  = File.read_lines("memoricimetiere/family/sister.txt").uniq.sort

      File.open("memoricimetiere/family/father.txt", "w") { |f|
        f.puts father
        f.puts buried_fathers
      }
  
      File.open("memoricimetiere/family/mother.txt", "w") { |f|
        f.puts mother
        f.puts buried_mothers
      }
  
      File.open("memoricimetiere/family/brother.txt", "w") { |f|
        f.puts brother
        f.puts buried_brothers
      }

      File.open("memoricimetiere/family/sister.txt", "w") { |f|
        f.puts sister
        f.puts buried_sisters
      }
    end

    def self.scatter_ashes
      old_graveyard = File.read_lines("memoricimetiere/urn.txt").uniq.sort.shuffle
      size_limit    = old_graveyard.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_graveyard[index]
  
        index = index + 1
      end
    end

    def self.scatter_three_ashes
      old_fathers  = File.read_lines("memoricimetiere/family/father.txt").uniq.sort.shuffle
      old_mothers  = File.read_lines("memoricimetiere/family/mother.txt").uniq.sort.shuffle
      old_children = File.read_lines("memoricimetiere/family/child.txt").uniq.sort.shuffle

      size_limit    = old_fathers.size.to_i
      index         = 0
  
      ## Scatters fathers ashes in the wind.
      size_limit.times do
        puts old_fathers[index]
  
        index = index + 1
      end
  
      ## Scatters mothers ashes in the wind
      size_limit    = old_mothers.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_mothers[index]
  
        index = index + 1
      end

      ## Scatters childrens ashes in the wind.
      size_limit    = old_children.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_children[index]
  
        index = index + 1
      end
    end

    def self.scatter_four_ashes
      old_fathers  = File.read_lines("memoricimetiere/family/father.txt").uniq.sort.shuffle
      old_mothers  = File.read_lines("memoricimetiere/family/mother.txt").uniq.sort.shuffle
      old_brothers = File.read_lines("memoricimetiere/family/brother.txt").uniq.sort
      old_sister   = File.read_lines("memoricimetiere/family/sister.txt").uniq.sort

      size_limit    = old_fathers.size.to_i
      index         = 0
  
      ## Scatters fathers ashes in the wind.
      size_limit.times do
        puts old_fathers[index]
  
        index = index + 1
      end
  
      ## Scatters mothers ashes in the wind
      size_limit    = old_mothers.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_mothers[index]
  
        index = index + 1
      end

      ## Scatters brothers ashes in the wind.
      size_limit    = old_brothers.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_brothers[index]
  
        index = index + 1
      end

      ## Scatters sisters ashes in the wind.
      size_limit    = old_sister.size.to_i
      index         = 0
  
      size_limit.times do
        puts old_sister[index]
  
        index = index + 1
      end
    end

    def self.yonagumi(current_year, specific_event)
      age_of_yonagumi = 11000.0
  
      age_percent = age_of_yonagumi - current_year
  
      " For a point of comparison: Yonagumi is #{age_percent} years old as of #{current_year}."

      Obelisk::DataRecycling.obelisk("For a point of comparison: Yonagumi is #{age_percent} years old as of #{current_year}.")
      Obelisk::DataRecycling.scatter_ashes
    end

    def self.age_comparison(current_year, age_historical, specific_event)
      years_ago = current_year - age_historical
  
      print "The current year is #{current_year}, #{specific_event} is #{years_ago} years ago."
      puts Obelisk::DataRecycling.yonagumi(2026.0, "#{specific_event}")
      
      Obelisk::DataRecycling.obelisk("The current year is #{current_year}, #{specific_event} is #{years_ago} years ago.")
    end
  end
end

#########################################################################################
#                             Generate Bounded Probability                              #
#########################################################################################
# This elements places in uppder bound on how high a probability can become in order to #
# avoid the need for clamping them down into percents. This process is slightly based   #
# on how many white keys are on a piano. This may be expanded to factors in flats and   #
# sharps.                                                                               #
#########################################################################################
def generate_bounded_probability
  assumed_percentage = "0."

  alpha = ["c", "d", "e", "f", "g", "a", "b"]
  
  a = alpha.sample
  b = alpha.sample
  c = alpha.sample
  d = alpha.sample
  e = alpha.sample
  f = alpha.sample
  g = alpha.sample
  
  "#{assumed_percentage}#{c}#{d}#{e}#{f}#{g}#{a}#{b}"
end

def convert_to_piano_to_percent(fake_percent)
  # if number is 0.eaaaaf, convert to real percent
  real_percent = fake_percent.tr ".cdefgab", ".0123456"
  real_percent = real_percent.to_f

  real_percent
end

def logprob(lowest_probability, highest_probability)
  logarithm = lowest_probability / highest_probability
  
  logarithm
end

def nuitmarcheuse(n1, n2, i1, i2, g1, g2,
                  h1, h2, t1, t2, w1, w2,
                  a1, a2, l1, l2, k1, k2,
                  e1, e2, r1, r2, b1, b2,
                  c1, c2, d1, d2, f1, f2,
                  j1, j2, m1, m2, o1, o2,
                  p1, p2, q1, q2, s1, s2,
                  u1, u2,         v1, v2) # Lines 37, 41, 44, 49, 53

  n = [n1, n2]
  i = [i1, i2]
  g = [g1, g2]
  h = [h1, h2]
  t = [t1, t2]
  w = [w1, w2]
  a = [a1, a2]
  l = [l1, l2]
  k = [k1, k2]
  e = [e1, e2]
  r = [r1, r2]
  b = [b1, b2]
  c = [c1, c2]
  d = [d1, d2]
  f = [f1, f2]
  j = [j1, j2]
  m = [m1, m2]
  o = [o1, o2]
  p = [p1, p2]
  q = [q1, q2]
  s = [s1, s2]
  u = [u1, u2]
  v = [v1, v2]
  
  nightwalker_symbols = [[
    [n[0], i[0], g[0]], [e[0], r[0], a[0]], [j[0], k[0], m[0]],
    [h[0], t[0], w[0]], [b[0], c[0], d[0]], [o[0], p[0], q[0]],
    [a[0], l[0], k[0]], [e[0], f[0], g[0]], [s[0], u[0], v[0]],
  ], [
    [j[0], k[0], m[0]], [n[0], i[0], g[0]], [e[0], r[0], a[0]],
    [o[0], p[0], q[0]], [h[0], t[0], w[0]], [b[0], c[0], d[0]],
    [s[0], u[0], v[0]], [a[0], l[0], k[0]], [e[0], f[0], g[0]],
  ], [
    [e[0], r[0], a[0]], [j[0], k[0], m[0]], [n[0], i[0], g[0]],
    [b[0], c[0], d[0]], [o[0], p[0], q[0]], [h[0], t[0], w[0]],
    [e[0], f[0], g[0]], [s[0], u[0], v[0]], [a[0], l[0], k[0]],
  ]]

  nightwalker_descriptions = [[
    [n[1], i[1], g[1]], [e[1], r[1], a[1]], [j[1], k[1], m[1]],
    [h[1], t[1], w[1]], [b[1], c[1], d[1]], [o[1], p[1], q[1]],
    [a[1], l[1], k[1]], [e[1], f[1], g[1]], [s[1], u[1], v[1]],
  ], [
    [j[1], k[1], m[1]], [n[1], i[1], g[1]], [e[1], r[1], a[1]],
    [o[1], p[1], q[1]], [h[1], t[1], w[1]], [b[1], c[1], d[1]],
    [s[1], u[1], v[1]], [a[1], l[1], k[1]], [e[1], f[1], g[1]],
  ], [
    [e[1], r[1], a[1]], [j[1], k[1], m[1]], [n[1], i[1], g[1]],
    [b[1], c[1], d[1]], [o[1], p[1], q[1]], [h[1], t[1], w[1]],
    [e[1], f[1], g[1]], [s[1], u[1], v[1]], [a[1], l[1], k[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = nightwalker_symbols[cur_row][cur_arr][cur_col]
  current_description = nightwalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "%Q(#{current_symbol}), %Q(#{current_description})"
end

def marcheuse_de_jour(d1, d2, a1, a2, y1, y2,
                      w1, w2, l1, l2, k1, k2,
                      e1, e2, r1, r2, b1, b2,
                      c1, c2, f1, f2, g1, g2,
                      h1, h2, i1, i2, j1, j2,
                      m1, m2, n1, n2, o1, o2,
                      p1, p2, q1, q2, s1, s2,
                      t1, t2, u1, u2, v1, v2,
                      x1, x2)
                      
  d = [ d1, d2 ]; a = [ a1, a2 ]; y = [ y1, y2 ];
  w = [ w1, w2 ]; l = [ l1, l2 ]; k = [ k1, k2 ];
  e = [ e1, e2 ]; r = [ r1, r2 ]; b = [ b1, d2 ];
  c = [ c1, c2 ]; f = [ f1, f2 ]; g = [ g1, g2 ];
  h = [ h1, h2 ]; i = [ i1, o2 ]; j = [ j1, j2 ];
  m = [ m1, m2 ]; n = [ n1, n2 ]; o = [ o1, o2 ];
  p = [ p1, p2 ]; q = [ q1, q2 ]; s = [ s1, s2 ];
  t = [ t1, t2 ]; u = [ u1, u2 ]; v = [ v1, b2 ];
  x = [ x1, x2 ]

  daywalker_symbols = [[
    [d[0], a[0], y[0]], [c[0], f[0], g[0]], [p[0], q[0], s[0]],
    [w[0], l[0], k[0]], [h[0], i[0], j[0]], [t[0], u[0], v[0]],
    [e[0], r[0], b[0]], [m[0], n[0], o[0]], [w[0], x[0], y[0]],
  ], [
    [p[0], q[0], s[0]], [d[0], a[0], y[0]], [c[0], f[0], g[0]],
    [t[0], u[0], v[0]], [w[0], l[0], k[0]], [h[0], i[0], j[0]],
    [w[0], x[0], y[0]], [e[0], r[0], b[0]], [m[0], n[0], o[0]],
  ], [
    [c[0], f[0], g[0]], [p[0], q[0], s[0]], [d[0], a[0], y[0]],
    [h[0], i[0], j[0]], [t[0], u[0], v[0]], [w[0], l[0], k[0]],
    [m[0], n[0], o[0]], [w[0], x[0], y[0]], [e[0], r[0], b[0]],
  ]]
  
  daywalker_descriptions = [[
    [d[1], a[1], y[1]], [c[1], f[1], g[1]], [p[1], q[1], s[1]],
    [w[1], l[1], k[1]], [h[1], i[1], j[1]], [t[1], u[1], v[1]],
    [e[1], r[1], b[1]], [m[1], n[1], o[1]], [w[1], x[1], y[1]],
  ], [
    [p[1], q[1], s[1]], [d[1], a[1], y[1]], [c[1], f[1], g[1]],
    [t[1], u[1], v[1]], [w[1], l[1], k[1]], [h[1], i[1], j[1]],
    [w[1], x[1], y[1]], [e[1], r[1], b[1]], [m[1], n[1], o[1]],
  ], [
    [c[1], f[1], g[1]], [p[1], q[1], s[1]], [d[1], a[1], y[1]],
    [h[1], i[1], j[1]], [t[1], u[1], v[1]], [w[1], l[1], k[1]],
    [m[1], n[1], o[1]], [w[1], x[1], y[1]], [e[1], r[1], b[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = daywalker_symbols[cur_row][cur_arr][cur_col]
  current_description = daywalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "%Q(#{current_symbol}), %Q(#{current_description})"

  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",       current_information)
end


module Ahuzacos
  #########################################################################################
  #                                   Subjects And Verbs                                  #
  #########################################################################################
  # The rest of the French grammar that doesnt need to have a specific word class.        #
  #########################################################################################
  class Subject
    def self.pronoun(specify_pronoun)
      specify_pronoun
    end
  end

  class Verb
    def self.mange(specify_eaten)
      "un / une mange #{specify_eaten}"
    end

    def self.coupe(specify_chopped)
      "un / une coupe #{specify_chopped}"
    end

    def self.tombe(specify_fallen)
      "un / une tombe #{specify_fallen}"
    end
  end

  #########################################################################################
  #                                  Genders de Francais                                  #
  #########################################################################################
  # This is where the basic word classes from Francais goes, for classifying everything   #
  # in the current language of prestige. There is a few exceptions that either denote     #
  # Japanese of origin on are supernatural or cursed in nature.                           #
  #########################################################################################
  class Le
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                                     Les Coloures                                      #
    #########################################################################################
    # These color sets are based on RGB and CYMK rather than the full color spectrum. I     #
    # will gradually expand these color names to include the full French color spectrum     #
    # that are covered in the masculine gender.                                             #
    #########################################################################################
    ## Shades
    define_method self.noir_one(black_thing),   "Le #{black_thing} noir"
    define_method self.gris_one(grey_thing),     "Le #{grey_thing} gris"
    define_method self.blanc_one(white_thing), "Le #{white_thing} blanc"

    ## Primary Colours
    define_method self.rouge_one(red_thing),   "Le #{red_thing} rouge"
    define_method self.vert_one(green_thing), "Le #{green_thing} vert"
    define_method self.bleu_one(blue_thing),   "Le #{blue_thing} bleu"

    define_method self.rouge_two(red_thing),   "Le #{red_thing} rouge"
    define_method self.vert_two(green_thing), "Le #{green_thing} vert"
    define_method self.bleu_two(blue_thing),   "Le #{blue_thing} bleu"
  
    ## Secondary Colors
    define_method self.jaune(yellow_thing),       "Le #{yellow_thing} jaune"
    define_method self.magenta(magenta_thing), "Le #{magenta_thing} magenta"
    define_method self.cyan(cyan_thing),             "Le #{cyan_thing} cyan"
  
    ## Other Colors
    define_method self.violette(purple_thing),     "Le #{purple_thing} violette"
    define_method self.citrone(lime_thing),        "Le #{lime_thing} citrone"
    define_method self.orange(orange_thing),       "Le #{orange_thing} orange"
    define_method self.vermillon(vermillon_thing), "Le #{vermillon} vermillon"
    define_method self.ambre(amber_thing),         "Le #{amber_thing} ambre"

    #########################################################################################
    #                                       Le Pets                                         #
    #########################################################################################
    define_method self.chat(cat_adjective),                          "Le chat #{cat_adjective} " # A cat
    define_method self.chien(dog_adjective),                        "Le chien #{dog_adjective} " # A dog
    define_method self.cochon_d_inde(gpig_adjective),      "Le cochon_dinde #{gpig_adjective} " # A guinea pig
    define_method self.hamster(hamster_adjective),            "Le hamster #{hamster_adjective}" # A hamster
    define_method self.lapin(rabbit_adjective),                  "Le lapin #{rabbit_adjective}" # A rabbit
    define_method self.lezard(lizard_adjective),                "Le lezard #{lizard_adjective}" # A lizard
    define_method self.perroquet(parrot_adjective),          "Le perroquet #{parrot_adjective}" # A parrot
    define_method self.poisson_orange(goldfish_adjective),   "Le poisson #{goldfish_adjective}" # A goldfish

    #############################################################################################
    #                                    Select Farm Animals                                    #
    #############################################################################################
    define_method self.loup(wolf_adjective),                         "Le loup #{wolf_adjective}"
    define_method self.renard(fox_adjective),                          "Le fox #{fox_adjective}"
    define_method self.agneau(lamb_adjective),                     "Le agneau #{lamb_adjective}"
    define_method self.ane(donkey_adjective),                       "Le ane #{donkey_adjective}"
    define_method self.canard(duck_adjective),                     "Le canard #{duck_adjective}"
    define_method self.cheval(horse_adjective),                   "Le cheval #{horse_adjective}"
    define_method self.chevre(goat_adjective),                     "Le chevre #{goat_adjective}"
    define_method self.cochon(pig_adjective),                       "Le cochon #{pig_adjective}"
    define_method self.coq(rooster_adjective),                     "Le coq #{rooster_adjective}"
    define_method self.mouton(sheep_adjective),                   "Le mouton #{sheep_adjective}"
    define_method self.poney(pony_adjective),                       "Le poney #{pony_adjective}"
    define_method self.poussin(chick_adjective),                 "Le poussin #{chick_adjective}"
    define_method self.veau(calf_adjective),                         "Le veau #{celf_adjective}"

    #########################################################################################
    #                               Les Animeux De Le Foret                                 #
    #########################################################################################
    # This is for generating strings for animals into Francais. Note that this may also     #
    # include animals of fantasy and fantistique origin. ( Fantastique is a specific sub    #
    # genre of fantasy fiction. These animals utilize the masculine word class.             #
    #########################################################################################
    define_method self.cerf(deer_adjective),                         "Le cerf #{deer_adjective}"
    define_method self.ours(bear_adjective),                         "Le ours #{bear_adjective}"
    define_method self.raton_laveur(racoon_adjective),     "Le raton laveur #{racoon_adjective}"

    #############################################################################################
    #                                     Dungeon Crawling                                      #
    #############################################################################################
    define_method self.rat(rat_adjective),          "Le rat #{rat_adjective}"
    define_method self.araignee(spider_adjective),  "Le araignee #{spider_adjective}"
    define_method self.gobelin(goblin_adjective),   "Le gobelin #{goblin_adjective}"
    define_method self.squelette(undead_adjective), "Le squelette #{undead_adjective}" # consider inventing a term
    define_method self.limon(sludge_adjective),      "La limon #{sludge_adjective}"

    ## Specifies a quality for a specific one-way dungeon.
    define_method self.donjon_unique(passage_adjective), "Le donjon a sens unique #{passage_adjective}"
  
    #############################################################################################
    #                                      Les Familles                                         #
    #############################################################################################

    #############################################################################################
    #                                 Masculine Class Monsters                                  #
    #############################################################################################
    define_method self.wancien(cthulhu_adjective), "Le wancien #{cthulhu_adjective}"
  
    #############################################################################################
    #                                  Masculine Class Traps                                    #
    #############################################################################################
    define_method self.mien_poison(mine_adjective), "Le mien poison #{mine_adjective}"
    define_method self.pointe_de_le_radeau(raft_adjective), "Pointe De Le Radeau, cest #{raft_adjective}."

    #############################################################################################
    #                                Food Items For Journeying                                  #
    #############################################################################################
    define_method self.pizza(topingu), "Topingu pour le pizza est #{topingu}."
  end

  class La
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                                     Les Coloures                                      #
    #########################################################################################
    # These color sets are based on RGB and CYMK rather than the full color spectrum. I     #
    # will gradually expand these color names to include the full French color spectrum     #
    # that are covered in the masculine gender.                                             #
    #########################################################################################
    define_method self.chartreuse(chartreuse_thing), "La #{chartreuse_thing} chartreuse"

    #############################################################################################
    #                                    Select Farm Animals                                    #
    #############################################################################################
    define_method self.poule(chicken_adjective),         "La poule #{chicken_adjective}"
    define_method self.souris(mouse_adjective),           "La souris #{mouse_adjective}"
    define_method self.vache(cow_adjective),                 "La vache #{cow_adjective}"
  
    #########################################################################################
    #                               Les Animeux De Le Foret                                 #
    #########################################################################################
    # This is for generating strings for animals into Francais. Note that this may also     #
    # include animals of fantasy and fantistique origin. ( Fantastique is a specific sub    #
    # genre of fantasy fiction. These animals utilize the feminine word class.              #
    #########################################################################################
    define_method self.chouette(owl_adjective),           "La chouette #{owl_adjective}"

    #############################################################################################
    #                                     Dungeon Crawling                                      #
    #############################################################################################
    define_method self.chauve_souris(bat_adjective), "La chauve-souris #{bat_adjective}"

    #############################################################################################
    #                                         Unclear                                           #
    #############################################################################################
    # These are for terms where its unclear whether its referring to the ceramic or the thing   #
    # that a ceramic holds.                                                                     #
    #############################################################################################
    define_method self.vase(vase_adjective), "La vase #{vase_adjective}"
  end

  class Les
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                                     Les Animeux                                       #
    #########################################################################################
    # This is for generating strings for animals into Francais. Note that this may also     #
    # include animals of fantasy and fantistique origin. ( Fantastique is a specific sub    #
    # genre of fantasy fiction. These animals utilize the plural word class.                #
    #########################################################################################
    define_method self.troupeau(herd_adjective), "Les troupeaus #{herd_adjective}"

    #########################################################################################
    #                                  Execution Methods                                    #
    #########################################################################################
    define_method self.faiseur_de_veuves(widowed_adjective), "Les feaiseur de veuves #{widowed_adjective}"
  
    #########################################################################################
    #                                  Plural Class Gear                                    #
    #########################################################################################
    define_method self.axes_de_urgence(ax_adjective), "Les Axes De Urgence #{ax_adjective}"
  
    define_method self.pizzas(topingos), "Anos topingos pour les pizzas sont #{topingos}."
  end

  ## Les genders de feux pour Nihongo
  class Anu
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                               Pseudo Masculine Class Monsters                         #
    ######################################################################################### 
    define_method self.umigarugu(gargoyal_adjective), "Anu Umigarugo #{gargoyal_adjective}"
  end

  class Ana
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                              Pseudo Feminine Class Monsters                           #
    #########################################################################################
    define_method self.girocinopeqa(plate_adjective), "Ana girocinopeqa #{plate_adjective}" # Girochin Plaque
  end

  class Anos
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    #########################################################################################
    #                                  Format Of Narrative                                  #
    #########################################################################################
    # This refers to a four-frame manga like format styled kind 4-koma, but specialized in  #
    # serious and morbid topics in ki-sho-ten-ketsu in a French dialect.                    #
    #########################################################################################
    define_method self.qutarocaderos(format_adjective), "Anos qutarocaderos #{format_adjective}"
    define_method        self.manfra(format_adjective), "Le manfra #{format_adjective}"
  
    #########################################################################################
    #                                  Pseudo Plural Class Gear                             #
    #########################################################################################
    define_method self.kaidokuzaios(antidote_adjective), "Anos Kaidokuzaios #{antidote_adjective}"
  end

  #############################################################################################
  #                                     Hybrid PortManteau                                    #
  #############################################################################################
  class Te
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    ###########################################################################################
    #                       Masculine Class Hybrid Port Manteau Monster                       #
    ###########################################################################################
    define_method self.sepeceterekimige(spectre_adjective),  "Te sepeceterekimige #{spectre_adjective}" # spectre_de_kimigayo
    define_method self.acideserupenete(serpent_adjective),   "Te acideserupenete #{serpent_adjective}" # Acid Serpent
    define_method self.acideduragone(dragon_adjective),      "Te acideduragone #{dragon_adjective}"

    ###########################################################################################
    ##
    ###########################################################################################
  end

  class Ta
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    ###########################################################################################
    #                       Feminine Class Hybrid Port Manteau Monster                       #
    ###########################################################################################
    define_method self.sepecetere_imeperaterica(spectre_adjective), "Ta sepecetere iweperaterica #{spectre_adjective}" # spectre de imperatrice
    define_method self.noneseturasona(nun_adjective),               "Ta noneseturasona #{nun_adjective}"
    define_method self.habucorosa(female_elder_god_adjective),      "Ta habucorosa #{female_elder_god_adjective}"
  end

  class Deso
    macro define_method(name, content)
      def {{name}}
        {{content}}
      end
    end

    ###########################################################################################
    #                         Hybrid Plural Class Monsters And Traps                          #
    ###########################################################################################
    define_method self.teruposva(teruposva_adjective), "Deso teruposva #{teruposva_adjective}" # troupeau de sale
    define_method self.kokenopo(moss_adjective),             "Deso kokenopo #{moss_adjective}" # Koke No Poison
  end
end

###########################################################################################
#                                       Essentials                                        #
###########################################################################################
# Essential functions for Awasuno Sector Four, that is similar to standard Awasunu. But   #
# that also include transpilation to Common Lisp.                                         #
###########################################################################################
class Essentials
  macro define_method(name, content)
    def {{name}}
      {{content}}
    end
  end

  def self.encrire(input, fname)
    to_lisp = <<-LISP
    (princ "#{input}")
    LISP

    File.open("#{fname}.lisp", "w") { |f|
      f.puts to_lisp
    }

    File.open("#{fname}.awa", "a") { |f|
      f.puts "encrire #{input} #{fname}"
    }

    print input
  end

  def self.encrireln(input, fname)
    to_lisp = <<-LISP
    (princ "#{input}")
    LISP

    File.open("#{fname}.lisp", "w") { |f|
      f.puts to_lisp
    }

    File.open("#{fname}.awa", "w") { |f|
      f.puts "encrire #{input} #{fname}"
    }

    puts input
  end

  def self.lisent(infname, outfname)
    new_file   = File.read_lines(infname)
    size_limit = new_file.size.to_i
    index = 0

    size_limit.times do
      print new_file[index]

      index = index + 1
    end
  end

  def self.lisentln(infname, outfname)
    new_file   = File.read_lines(infname)
    size_limit = new_file.size.to_i
    index = 0

    size_limit.times do
      puts new_file[index]

      index = index + 1
    end
  end

  define_method   self.je(verb, object),   Essentials.encrire("Je #{verb} #{object}.", "je")
  define_method self.vous(verb, object), Essentials.encrire("Vous #{verb} #{object}.", "vous")
  define_method  self.toi(verb, object),  Essentials.encrire("Toi #{verb} #{object}.", "toi")
  define_method self.il(verb, object),     Essentials.encrire("Il #{verb} #{object}.", "il")
  define_method self.elle(verb, object), Essentials.encrire("Elle #{verb} #{object}.", "elle")
  define_method self.nous(verb, object), Essentials.encrire("Nous #{verb} #{object}.", "nous")
end

###########################################################################################
#                           OVS or Object Adjective Specification                         #
###########################################################################################
class Ovs
  def self.pomme(*kwargs)
    size_limit = kwargs.size.to_i
    index = 0

    puts "["

    size_limit.times do
      print "%Q(pomme #{kwargs[index]}), "

      index = index + 1
    end

    puts "] je mange."
  end

  def self.banane(*kwargs)
    size_limit = kwargs.size.to_i
    index = 0

    puts "["

    size_limit.times do
      print "%Q(banane #{kwargs[index]}), "

      index = index + 1
    end

    puts "] je mange."
  end

  def self.citrone(*kwargs)
    size_limit = kwargs.size.to_i
    index = 0

    puts "["

    size_limit.times do
      print "%Q(citrone #{kwargs[index]}), "

      index = index + 1
    end

    puts "] je mange."
  end
end

###########################################################################################
#                       OSV or Object specified to perform an action                      #
###########################################################################################
class Osv
  macro define_method(name, content)
    def {{name}}
      {{content}}
    end
  end

  define_method  self.diary(subject, verb),    Essentials.encrire(%Q(Diary #{subject} #{verb}.), "djourn")
  define_method self.mglass(subject, verb),  Essentials.encrire(%Q(Magnify #{subject} #{verb}.), "mglass")
  define_method self.livre(subject, verb),  Essentials.encrire(%Q(Le Livre #{subject} #{verb}.), "livre")
end

###########################################################################################
#                                 Recursive Bootstrapping                                 #
###########################################################################################
class RecursiveFunctionality
  macro recursive_method(recursive_method_name, regular_content, recursive_content)
    def {{recursive_method_name}}
      {{recursive_content}}

      {{regular_content}}
    end
  end

  recursive_method self.etude(pronoun, object, verb, outfname), "#{pronoun} etude #{object} #{verb}.", File.open("#{outfname}.awa", "a") { |f| f.puts "#{pronoun} #{object} #{verb} #{outfname}" }
end

#######################################################################################
#                                        REPL                                         #
#######################################################################################
def awasunu4_repl
  file_name = ARGV[0]

  read_file = File.read_lines(file_name)

  total_lines = read_file.size.to_i
  index       = 0

  if total_lines > 0
    total_lines.times do
      current_line = read_file[index]
  
      tokens       = current_line.split(" ")
      total_tokens = tokens.size.to_i
      token_index  = 0
    
      ## The actual tokens you'll be parsing.
      parsed_tokens = [] of String
    
      if total_tokens > 0

        total_tokens.times do
          current_token = tokens[token_index]
 
          parsed_tokens = parsed_tokens.push(current_token)
    
          token_index = token_index + 1
        end
        
        ###################################################################################################
        #                                           Essentials                                            #
        ###################################################################################################
        # This covers essential French grammar components that allow for you to read natural language as  #
        # Awasunu Sector 4 scripts.                                                                       #
        ###################################################################################################
        if    parsed_tokens[0] == "--"
        elsif parsed_tokens[0] == "#"
        elsif parsed_tokens[0] == ""
        elsif parsed_tokens[0] == "encrire"
          Essentials.encrire(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "encrireln"
          Essentials.encrireln(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "lisent"
          Essentials.lisentln(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "lisent"
          Essentials.lisentln(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "je"
          Essentials.je(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "vous"
          Essentials.vous(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "toi"
          Essentials.toi(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "il"
          Essentials.il(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "elle"
          Essentials.elle(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "nous"
          Essentials.nous(parsed_tokens[1], parsed_tokens[2])

        ###################################################################################################
        #                                             Obelisk                                             #
        ###################################################################################################
        elsif parsed_tokens[0] == "obelisk1"
          Obelisk::DataRecycling.obelisk(parsed_tokens[1])
        elsif parsed_tokens[0] == "obelisk2"
          Obelisk::DataRecycling.obelisk(parsed_tokens[1])

          Obelisk::DataRecycling.obelisk(parsed_tokens[2])
        elsif parsed_tokens[0] == "obelisk3"
          Obelisk::DataRecycling.obelisk(parsed_tokens[1])

          Obelisk::DataRecycling.obelisk(parsed_tokens[2])

          Obelisk::DataRecycling.obelisk(parsed_tokens[3])
        elsif parsed_tokens[0] == "obelisk4"
          Obelisk::DataRecycling.obelisk(parsed_tokens[1])

          Obelisk::DataRecycling.obelisk(parsed_tokens[2])

          Obelisk::DataRecycling.obelisk(parsed_tokens[3])

          Obelisk::DataRecycling.obelisk(parsed_tokens[4])
        elsif parsed_tokens[0] == "scash"
          Obelisk::DataRecycling.scatter_ashes
        ###########################################################################################
        #                       OSV or Object specified to perform an action                      #
        ###########################################################################################
        elsif parsed_tokens[0] == "djourn"
          Osv.diary(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "mglass"
          Osv.mglass(parsed_tokens[1], parsed_tokens[2])
        elsif parsed_tokens[0] == "livre"
          Osv.livre(parsed_tokens[1], parsed_tokens[2])
        else
          current_token = tokens[token_index]
        
          puts current_token
        end
  
        index = index + 1
      end
    end
  else
    current_line = read_file[index]
   
    puts current_line
  end
end
