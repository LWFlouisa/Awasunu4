def diary(subject, verb)
  %Q(Diary #{subject} #{verb}.)
end

def mglass(subject, verb)
  %Q(Magnify #{subject} #{verb}.)
end

def livre(subject, verb)
  %Q(Le Livre #{subject} #{verb}.)
end
