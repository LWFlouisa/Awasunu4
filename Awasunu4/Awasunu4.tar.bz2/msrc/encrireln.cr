require "./src/awasunu4"

Essentials.encrireln(ARGV[0], ARGV[1])
