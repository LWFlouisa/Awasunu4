require "./src/awasunu4"

Essentials.encrire(ARGV[0], ARGV[1])
