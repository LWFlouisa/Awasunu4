require "./src/awasunu4"

Essentials.lisent(ARGV[0], ARGV[1])
