recursive_method etude(object, verb, outfname), puts "Je etude #{object} #{verb}.", File.open("#{outfname}.awa", "a") { |f| f.puts "#{object} #{verb} #{outfname}" }
