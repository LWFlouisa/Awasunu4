def encrire(input, fname)
  to_lisp = LISP
  (defun #{fname} ()
    (princ "#{input}")
  )
  LISP

  File.open("#{fname}.lisp", "w") { |f|
    f.puts to_lisp
  }

  File.open("#{fname}.awa", "w") { |f|
    f.puts "encrire #{input} #{fname}"
  }

  print input
end

def encrireln(input, fname)
  to_lisp = LISP
  (defun #{fname} ()
    (princ "#{input}")
  )
  LISP

  File.open("#{fname}.lisp", "w") { |f|
    f.puts to_lisp
  }

  File.open("#{fname}.awa", "w") { |f|
    f.puts "encrire #{input} #{fname}"
  }

  puts input
end

def lisent(infname, outfname)
  new_file   = File.read_lines(infname)
  size_limit = new_file.size.to_i
  index = 0

  size_limit.times do
    puts new_file[index]

    index = index + 1
  end
end
