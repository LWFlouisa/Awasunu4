
def nuitmarcheuse(n1, n2, i1, i2, g1, g2,
                  h1, h2, t1, t2, w1, w2,
                  a1, a2, l1, l2, k1, k2,
                  e1, e2, r1, r2, b1, b2,
                  c1, c2, d1, d2, f1, f2,
                  j1, j2, m1, m2, o1, o2,
                  p1, p2, q1, q2, s1, s2,
                  u1, u2,         v1, v2) # Lines 37, 41, 44, 49, 53

  n = [n1, n2]
  i = [i1, i2]
  g = [g1, g2]
  h = [h1, h2]
  t = [t1, t2]
  w = [w1, w2]
  a = [a1, a2]
  l = [l1, l2]
  k = [k1, k2]
  e = [e1, e2]
  r = [r1, r2]
  b = [b1, b2]
  c = [c1, c2]
  d = [d1, d2]
  f = [f1, f2]
  j = [j1, j2]
  m = [m1, m2]
  o = [o1, o2]
  p = [p1, p2]
  q = [q1, q2]
  s = [s1, s2]
  u = [u1, u2]
  v = [v1, v2]
  
  nightwalker_symbols = [[
    [n[0], i[0], g[0]], [e[0], r[0], a[0]], [j[0], k[0], m[0]],
    [h[0], t[0], w[0]], [b[0], c[0], d[0]], [o[0], p[0], q[0]],
    [a[0], l[0], k[0]], [e[0], f[0], g[0]], [s[0], u[0], v[0]],
  ], [
    [j[0], k[0], m[0]], [n[0], i[0], g[0]], [e[0], r[0], a[0]],
    [o[0], p[0], q[0]], [h[0], t[0], w[0]], [b[0], c[0], d[0]],
    [s[0], u[0], v[0]], [a[0], l[0], k[0]], [e[0], f[0], g[0]],
  ], [
    [e[0], r[0], a[0]], [j[0], k[0], m[0]], [n[0], i[0], g[0]],
    [b[0], c[0], d[0]], [o[0], p[0], q[0]], [h[0], t[0], w[0]],
    [e[0], f[0], g[0]], [s[0], u[0], v[0]], [a[0], l[0], k[0]],
  ]]

  nightwalker_descriptions = [[
    [n[1], i[1], g[1]], [e[1], r[1], a[1]], [j[1], k[1], m[1]],
    [h[1], t[1], w[1]], [b[1], c[1], d[1]], [o[1], p[1], q[1]],
    [a[1], l[1], k[1]], [e[1], f[1], g[1]], [s[1], u[1], v[1]],
  ], [
    [j[1], k[1], m[1]], [n[1], i[1], g[1]], [e[1], r[1], a[1]],
    [o[1], p[1], q[1]], [h[1], t[1], w[1]], [b[1], c[1], d[1]],
    [s[1], u[1], v[1]], [a[1], l[1], k[1]], [e[1], f[1], g[1]],
  ], [
    [e[1], r[1], a[1]], [j[1], k[1], m[1]], [n[1], i[1], g[1]],
    [b[1], c[1], d[1]], [o[1], p[1], q[1]], [h[1], t[1], w[1]],
    [e[1], f[1], g[1]], [s[1], u[1], v[1]], [a[1], l[1], k[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = nightwalker_symbols[cur_row][cur_arr][cur_col]
  current_description = nightwalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "%Q(#{current_symbol}), %Q(#{current_description})"
end

def marcheuse_de_jour(d1, d2, a1, a2, y1, y2,
                      w1, w2, l1, l2, k1, k2,
                      e1, e2, r1, r2, b1, b2,
                      c1, c2, f1, f2, g1, g2,
                      h1, h2, i1, i2, j1, j2,
                      m1, m2, n1, n2, o1, o2,
                      p1, p2, q1, q2, s1, s2,
                      t1, t2, u1, u2, v1, v2,
                      x1, x2)
                      
  d = [ d1, d2 ]; a = [ a1, a2 ]; y = [ y1, y2 ];
  w = [ w1, w2 ]; l = [ l1, l2 ]; k = [ k1, k2 ];
  e = [ e1, e2 ]; r = [ r1, r2 ]; b = [ b1, d2 ];
  c = [ c1, c2 ]; f = [ f1, f2 ]; g = [ g1, g2 ];
  h = [ h1, h2 ]; i = [ i1, o2 ]; j = [ j1, j2 ];
  m = [ m1, m2 ]; n = [ n1, n2 ]; o = [ o1, o2 ];
  p = [ p1, p2 ]; q = [ q1, q2 ]; s = [ s1, s2 ];
  t = [ t1, t2 ]; u = [ u1, u2 ]; v = [ v1, b2 ];
  x = [ x1, x2 ]

  daywalker_symbols = [[
    [d[0], a[0], y[0]], [c[0], f[0], g[0]], [p[0], q[0], s[0]],
    [w[0], l[0], k[0]], [h[0], i[0], j[0]], [t[0], u[0], v[0]],
    [e[0], r[0], b[0]], [m[0], n[0], o[0]], [w[0], x[0], y[0]],
  ], [
    [p[0], q[0], s[0]], [d[0], a[0], y[0]], [c[0], f[0], g[0]],
    [t[0], u[0], v[0]], [w[0], l[0], k[0]], [h[0], i[0], j[0]],
    [w[0], x[0], y[0]], [e[0], r[0], b[0]], [m[0], n[0], o[0]],
  ], [
    [c[0], f[0], g[0]], [p[0], q[0], s[0]], [d[0], a[0], y[0]],
    [h[0], i[0], j[0]], [t[0], u[0], v[0]], [w[0], l[0], k[0]],
    [m[0], n[0], o[0]], [w[0], x[0], y[0]], [e[0], r[0], b[0]],
  ]]
  
  daywalker_descriptions = [[
    [d[1], a[1], y[1]], [c[1], f[1], g[1]], [p[1], q[1], s[1]],
    [w[1], l[1], k[1]], [h[1], i[1], j[1]], [t[1], u[1], v[1]],
    [e[1], r[1], b[1]], [m[1], n[1], o[1]], [w[1], x[1], y[1]],
  ], [
    [p[1], q[1], s[1]], [d[1], a[1], y[1]], [c[1], f[1], g[1]],
    [t[1], u[1], v[1]], [w[1], l[1], k[1]], [h[1], i[1], j[1]],
    [w[1], x[1], y[1]], [e[1], r[1], b[1]], [m[1], n[1], o[1]],
  ], [
    [c[1], f[1], g[1]], [p[1], q[1], s[1]], [d[1], a[1], y[1]],
    [h[1], i[1], j[1]], [t[1], u[1], v[1]], [w[1], l[1], k[1]],
    [m[1], n[1], o[1]], [w[1], x[1], y[1]], [e[1], r[1], b[1]],
  ]]

  row_options = [0, 1, 2]
  col_options = [0, 1, 2]
  arr_options = [0, 1, 2]
  
  cur_row = row_options.sample
  cur_col = col_options.sample
  cur_arr = arr_options.sample
  
  current_symbol      = daywalker_symbols[cur_row][cur_arr][cur_col]
  current_description = daywalker_descriptions[cur_row][cur_arr][cur_col]
  current_probability = 0.33 * 0.33 * 0.33
  current_information = "%Q(#{current_symbol}), %Q(#{current_description})"

  File.write("data/statistics/probability/current_probability.txt", "#{current_probability}")
  File.write("data/statistics/label/current_information.txt",       current_information)
end
