def je(verb, object)
  encrire("Je #{verb} #{object}.")
end

def vous(verb, object)
  encrire("Vous #{verb} #{object}.")
end

def toi(verb, object)
  encrire("Toi #{verb} #{object}.")
end

def il(verb, object)
  encrire("Il #{verb} #{object}.")
end

def elle(verb, object)
  encrire("Elle #{verb} #{object}.")
end

def nous(verb, object)
  encrire("Nous #{verb} #{object}.")
end
