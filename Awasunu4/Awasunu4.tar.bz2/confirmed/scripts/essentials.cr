def lisentln(infname, outfname)
  new_file   = File.read_lines(infname)
  size_limit = new_file.size.to_i
  index = 0

  size_limit.times do
    puts new_file[index]

    index = index + 1
  end
end
