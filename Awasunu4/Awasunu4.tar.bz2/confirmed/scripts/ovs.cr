def pomme(*kwargs)
  size_limit = kwargs.size.to_i
  index = 0

  puts "["

  size_limit.times do
    print "%Q(pomme #{kwargs[index]}), "

    index = index + 1
  end

  puts "] je mange."
end

def banane(*kwargs)
  size_limit = kwargs.size.to_i
  index = 0

  puts "["

  size_limit.times do
    print "%Q(banane #{kwargs[index]}), "

    index = index + 1
  end

  puts "] je mange."
end

def citrone(*kwargs)
  size_limit = kwargs.size.to_i
  index = 0

  puts "["

  size_limit.times do
    print "%Q(citrone #{kwargs[index]}), "

    index = index + 1
  end

  puts "] je mange."
end
